export function getSiteUrl(): string {
  const envUrl = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (envUrl && envUrl.length > 0) {
    return envUrl.startsWith("http") ? envUrl : `https://${envUrl}`;
  }

  const vercelUrl = (process.env.VERCEL_PROJECT_PRODUCTION_URL || process.env.VERCEL_URL)?.trim();
  if (vercelUrl && vercelUrl.length > 0) {
    return `https://${vercelUrl}`;
  }

  return "http://localhost:3000";
}

export const siteConfig = {
  botName: "Sentrix",
  botLogo: "/sentrix-logo.png",
  botPfp: "/sentrix-logo.png",
  badge: "FREE PUBLIC DISCORD BOT",
  tagline: "The All-In-One Discord Security Bot",
  description:
    "Protect and manage your server with antinuke, automoderation, tickets, music, leveling and 599+ commands. 100% free.",
  developer: "Shailesh",
  teamName: "Sentrix Team",
  links: {
    invite:
      process.env.NEXT_PUBLIC_DISCORD_INVITE_URL ??
      "https://discord.com/oauth2/authorize?client_id=1550890394978361425&permissions=8&scope=bot+applications.commands",
    dashboard: process.env.NEXT_PUBLIC_DOCUMENTATION_URL ?? "https://sentrixx.antideploy.com/",
    support: process.env.NEXT_PUBLIC_SUPPORT_SERVER_URL ?? "#",
    docs: process.env.NEXT_PUBLIC_DOCUMENTATION_URL ?? "https://sentrixx.antideploy.com/",
    github: process.env.NEXT_PUBLIC_GITHUB_URL ?? "#",
    status: process.env.NEXT_PUBLIC_STATUS_URL ?? "#",
    changelog: "#",
    discord: process.env.NEXT_PUBLIC_SUPPORT_SERVER_URL ?? "#",
    x: "#",
  },
  nav: [
    { name: "Home", href: "#home" },
    { name: "Features", href: "#features" },
    { name: "Commands", href: "#commands" },
    { name: "Demo", href: "#dashboard" },
    { name: "FAQ", href: "#faq" },
  ],
  coreFeatures: [
    { id: "security", title: "Anti-Nuke Security", description: "Antinuke protection with whitelists, blacklists and emergency mode to keep your server safe.", badge: "Protection", icon: "ShieldAlert" },
    { id: "automod", title: "Automoderation", description: "Anti-spam, anti-link, anti-caps, anti-invite, mass-mention and emoji-spam filters.", badge: "Automatic", icon: "Lock" },
    { id: "logging", title: "Advanced Logging", description: "Detailed logs for server and member events so nothing goes unnoticed.", badge: "Audit", icon: "ChartNoAxesColumnIncreasing" },
    { id: "free", title: "Free For Everyone", description: "Every feature is free. No premium, no paywalls, just invite and use.", badge: "100% Free", icon: "Moon" },
  ],
  featureCards: [
    { title: "Moderation", icon: "Shield", points: ["Ban & Kick", "Warn & Timeout", "Lock & Hide Channels", "Snipe & Jail"] },
    { title: "Security", icon: "ShieldAlert", points: ["Antinuke & Whitelist", "Emergency Mode", "Blacklist & Block", "Advanced Logging"] },
    { title: "Music", icon: "Disc", points: ["Play in Voice", "Queue Controls", "Now Playing", "Voice Tools & J2C"] },
    { title: "Automation", icon: "Sparkles", points: ["Autorole", "Welcome & Join DM", "Autoreact & Responder", "Sticky Messages"] },
    { title: "Community & Fun", icon: "Zap", points: ["Leveling", "Games & Fun", "Birthdays & Counting", "Minecraft Status"] },
    { title: "Tickets & Growth", icon: "Ticket", points: ["Ticket System", "Giveaways", "Invite Tracker", "Vanity Roles"] },
  ],
  commandCategories: [
  "All",
  "Advance Logging",
  "Automoderation",
  "Autoreact & Responder",
  "Autorole & Invc",
  "Birthday",
  "Counting",
  "Customrole",
  "Encryption",
  "Fun",
  "Games",
  "Giveaway",
  "Ignore Channels",
  "Invite Tracker",
  "J2C (Join To Create)",
  "Joindm",
  "Minecraft",
  "Moderation",
  "Music",
  "Reaction Roles",
  "Security & Antinuke",
  "Server",
  "Sticky",
  "Ticket",
  "Utility",
  "Vanityroles",
  "Voice",
  "Welcomer"
],
  commands: [
  {
    "name": ">log",
    "description": "Sentrix Advance Logging command.",
    "category": "Advance Logging",
    "usage": ">log"
  },
  {
    "name": ">log config",
    "description": "Fully interactive configuration menu.",
    "category": "Advance Logging",
    "usage": ">log config"
  },
  {
    "name": ">log export",
    "description": "Export log data for the specified number of days.",
    "category": "Advance Logging",
    "usage": ">log export [days]"
  },
  {
    "name": ">log ignore",
    "description": "Manage ignore lists.",
    "category": "Advance Logging",
    "usage": ">log ignore [action] [target_type] [target]"
  },
  {
    "name": ">log reset",
    "description": "Reset logging configuration for the guild.",
    "category": "Advance Logging",
    "usage": ">log reset"
  },
  {
    "name": ">log search",
    "description": "Search through logs with comprehensive filtering options.",
    "category": "Advance Logging",
    "usage": ">log search [user] [category] [hours]"
  },
  {
    "name": ">log setup",
    "description": "Enhanced interactive setup with improved user experience.",
    "category": "Advance Logging",
    "usage": ">log setup"
  },
  {
    "name": ">log status",
    "description": "Display comprehensive logging status.",
    "category": "Advance Logging",
    "usage": ">log status"
  },
  {
    "name": ">log test",
    "description": "Send test log messages.",
    "category": "Advance Logging",
    "usage": ">log test [category]"
  },
  {
    "name": ">log toggle",
    "description": "Toggle logging categories on/off.",
    "category": "Advance Logging",
    "usage": ">log toggle [category] [enabled]"
  },
  {
    "name": ">addmessages",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">addmessages [member] [amount]"
  },
  {
    "name": ">automod",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">automod"
  },
  {
    "name": ">automod config",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">automod config"
  },
  {
    "name": ">automod disable",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">automod disable"
  },
  {
    "name": ">automod enable",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">automod enable"
  },
  {
    "name": ">automod logging",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">automod logging [channel]"
  },
  {
    "name": ">automod punishment",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">automod punishment"
  },
  {
    "name": ">bypass add",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">bypass add [user]"
  },
  {
    "name": ">bypass remove",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">bypass remove [user]"
  },
  {
    "name": ">bypass show",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">bypass show"
  },
  {
    "name": ">clearmessage",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">clearmessage [member]"
  },
  {
    "name": ">filter",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">filter"
  },
  {
    "name": ">filter disable",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">filter disable"
  },
  {
    "name": ">filter enable",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">filter enable"
  },
  {
    "name": ">ignore channel",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">ignore channel [channel]"
  },
  {
    "name": ">ignore reset",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">ignore reset"
  },
  {
    "name": ">ignore role",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">ignore role [role]"
  },
  {
    "name": ">ignore show",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">ignore show"
  },
  {
    "name": ">media",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">media"
  },
  {
    "name": ">media config",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">media config"
  },
  {
    "name": ">media remove",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">media remove"
  },
  {
    "name": ">media setup",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">media setup [channel]"
  },
  {
    "name": ">removemessages",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">removemessages [member] [amount]"
  },
  {
    "name": ">unignore channel",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">unignore channel [channel]"
  },
  {
    "name": ">unignore role",
    "description": "Sentrix Automoderation command.",
    "category": "Automoderation",
    "usage": ">unignore role [role]"
  },
  {
    "name": ">_ar config",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">_ar config"
  },
  {
    "name": ">_ar create",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">_ar create [name] [message]"
  },
  {
    "name": ">_ar delete",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">_ar delete [name]"
  },
  {
    "name": ">_ar edit",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">_ar edit [name] [message]"
  },
  {
    "name": ">autoresponder",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">autoresponder"
  },
  {
    "name": ">react",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">react"
  },
  {
    "name": ">react add",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">react add [trigger] [emojis]"
  },
  {
    "name": ">react list",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">react list"
  },
  {
    "name": ">react remove",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">react remove [trigger]"
  },
  {
    "name": ">react reset",
    "description": "Sentrix Autoreact & Responder command.",
    "category": "Autoreact & Responder",
    "usage": ">react reset"
  },
  {
    "name": ">_autorole config",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">_autorole config"
  },
  {
    "name": ">_autorole_bots add",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">_autorole_bots add [role]"
  },
  {
    "name": ">_autorole_bots remove",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">_autorole_bots remove [role]"
  },
  {
    "name": ">_autorole_humans add",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">_autorole_humans add [role]"
  },
  {
    "name": ">_autorole_humans remove",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">_autorole_humans remove [role]"
  },
  {
    "name": ">_autorole_reset all",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">_autorole_reset all"
  },
  {
    "name": ">_autorole_reset bots",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">_autorole_reset bots"
  },
  {
    "name": ">_autorole_reset humans",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">_autorole_reset humans"
  },
  {
    "name": ">autorole",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">autorole"
  },
  {
    "name": ">vcrole",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">vcrole"
  },
  {
    "name": ">vcrole add",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">vcrole add [role]"
  },
  {
    "name": ">vcrole config",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">vcrole config"
  },
  {
    "name": ">vcrole remove",
    "description": "Sentrix Autorole & Invc command.",
    "category": "Autorole & Invc",
    "usage": ">vcrole remove [role]"
  },
  {
    "name": ">birthday",
    "description": "Sentrix Birthday command.",
    "category": "Birthday",
    "usage": ">birthday"
  },
  {
    "name": ">birthdaysetup",
    "description": "Sentrix Birthday command.",
    "category": "Birthday",
    "usage": ">birthdaysetup [channel] [role]"
  },
  {
    "name": ">listbirthdays",
    "description": "Sentrix Birthday command.",
    "category": "Birthday",
    "usage": ">listbirthdays"
  },
  {
    "name": ">removebirthday",
    "description": "Sentrix Birthday command.",
    "category": "Birthday",
    "usage": ">removebirthday"
  },
  {
    "name": ">setbirthday",
    "description": "Sentrix Birthday command.",
    "category": "Birthday",
    "usage": ">setbirthday"
  },
  {
    "name": ">counting",
    "description": "Sentrix Counting command.",
    "category": "Counting",
    "usage": ">counting"
  },
  {
    "name": ">counting channel",
    "description": "Sentrix Counting command.",
    "category": "Counting",
    "usage": ">counting channel [channel]"
  },
  {
    "name": ">counting config",
    "description": "Sentrix Counting command.",
    "category": "Counting",
    "usage": ">counting config [mode]"
  },
  {
    "name": ">counting disable",
    "description": "Sentrix Counting command.",
    "category": "Counting",
    "usage": ">counting disable"
  },
  {
    "name": ">counting enable",
    "description": "Sentrix Counting command.",
    "category": "Counting",
    "usage": ">counting enable"
  },
  {
    "name": ">counting reset",
    "description": "Sentrix Counting command.",
    "category": "Counting",
    "usage": ">counting reset"
  },
  {
    "name": ">counting stats",
    "description": "Sentrix Counting command.",
    "category": "Counting",
    "usage": ">counting stats"
  },
  {
    "name": ">set config",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set config [context]"
  },
  {
    "name": ">set create",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set create [context] [name] [role]"
  },
  {
    "name": ">set delete",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set delete [context] [name]"
  },
  {
    "name": ">set friend",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set friend [context] [role]"
  },
  {
    "name": ">set girl",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set girl [context] [role]"
  },
  {
    "name": ">set guest",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set guest [context] [role]"
  },
  {
    "name": ">set list",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set list [context]"
  },
  {
    "name": ">set reqrole",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set reqrole [context] [role]"
  },
  {
    "name": ">set reset",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set reset [context]"
  },
  {
    "name": ">set staff",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set staff [context] [role]"
  },
  {
    "name": ">set vip",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">set vip [context] [role]"
  },
  {
    "name": ">setup",
    "description": "Sentrix Customrole command.",
    "category": "Customrole",
    "usage": ">setup [context]"
  },
  {
    "name": ">decode",
    "description": "All decode methods",
    "category": "Encryption",
    "usage": ">decode"
  },
  {
    "name": ">decode ascii85",
    "description": "Decode in ASCII85",
    "category": "Encryption",
    "usage": ">decode ascii85 [txtinput]"
  },
  {
    "name": ">decode base32",
    "description": "Decode in base32",
    "category": "Encryption",
    "usage": ">decode base32 [txtinput]"
  },
  {
    "name": ">decode base64",
    "description": "Decode in base64",
    "category": "Encryption",
    "usage": ">decode base64 [txtinput]"
  },
  {
    "name": ">decode base85",
    "description": "Decode in base85",
    "category": "Encryption",
    "usage": ">decode base85 [txtinput]"
  },
  {
    "name": ">decode hex",
    "description": "Decode in hex",
    "category": "Encryption",
    "usage": ">decode hex [txtinput]"
  },
  {
    "name": ">decode rot13",
    "description": "Decode in rot13",
    "category": "Encryption",
    "usage": ">decode rot13 [txtinput]"
  },
  {
    "name": ">encode",
    "description": "All encode methods",
    "category": "Encryption",
    "usage": ">encode"
  },
  {
    "name": ">encode ascii85",
    "description": "Encode in ASCII85",
    "category": "Encryption",
    "usage": ">encode ascii85 [txtinput]"
  },
  {
    "name": ">encode base32",
    "description": "Encode in base32",
    "category": "Encryption",
    "usage": ">encode base32 [txtinput]"
  },
  {
    "name": ">encode base64",
    "description": "Encode in base64",
    "category": "Encryption",
    "usage": ">encode base64 [txtinput]"
  },
  {
    "name": ">encode base85",
    "description": "Encode in base85",
    "category": "Encryption",
    "usage": ">encode base85 [txtinput]"
  },
  {
    "name": ">encode hex",
    "description": "Encode in hex",
    "category": "Encryption",
    "usage": ">encode hex [txtinput]"
  },
  {
    "name": ">encode rot13",
    "description": "Encode in rot13",
    "category": "Encryption",
    "usage": ">encode rot13 [txtinput]"
  },
  {
    "name": ">encryption",
    "description": "Show all available encryption commands",
    "category": "Encryption",
    "usage": ">encryption"
  },
  {
    "name": ">password",
    "description": "Generates a random secure password for you",
    "category": "Encryption",
    "usage": ">password"
  },
  {
    "name": ">8ball",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">8ball [question]"
  },
  {
    "name": ">anime",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">anime"
  },
  {
    "name": ">boy",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">boy"
  },
  {
    "name": ">brainrate",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">brainrate [user]"
  },
  {
    "name": ">coinflip",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">coinflip"
  },
  {
    "name": ">couple",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">couple"
  },
  {
    "name": ">dice",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">dice"
  },
  {
    "name": ">dumb",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">dumb [user]"
  },
  {
    "name": ">genius",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">genius [user]"
  },
  {
    "name": ">howhot",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">howhot [user]"
  },
  {
    "name": ">hug",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">hug [user]"
  },
  {
    "name": ">intelligence",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">intelligence [user]"
  },
  {
    "name": ">iq",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">iq [user]"
  },
  {
    "name": ">kiss",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">kiss [user]"
  },
  {
    "name": ">pat",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">pat [user]"
  },
  {
    "name": ">roast",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">roast [user]"
  },
  {
    "name": ">shipp",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">shipp [user1] [user2]"
  },
  {
    "name": ">simprate",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">simprate [user]"
  },
  {
    "name": ">slap",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">slap [user]"
  },
  {
    "name": ">tickle",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">tickle [user]"
  },
  {
    "name": ">toxic",
    "description": "Sentrix Fun command.",
    "category": "Fun",
    "usage": ">toxic [user]"
  },
  {
    "name": ">2048",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">2048"
  },
  {
    "name": ">_country_guesser end",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">_country_guesser end"
  },
  {
    "name": ">_country_guesser start",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">_country_guesser start"
  },
  {
    "name": ">battleship",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">battleship [player]"
  },
  {
    "name": ">blackjack",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">blackjack"
  },
  {
    "name": ">chess",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">chess [player]"
  },
  {
    "name": ">connectfour",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">connectfour [player]"
  },
  {
    "name": ">country-guesser",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">country-guesser"
  },
  {
    "name": ">lights-out",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">lights-out"
  },
  {
    "name": ">memory-game",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">memory-game"
  },
  {
    "name": ">number-slider",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">number-slider"
  },
  {
    "name": ">rps",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">rps [player]"
  },
  {
    "name": ">slots",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">slots"
  },
  {
    "name": ">tic-tac-toe",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">tic-tac-toe [player]"
  },
  {
    "name": ">wordle",
    "description": "Sentrix Games command.",
    "category": "Games",
    "usage": ">wordle"
  },
  {
    "name": ">gend",
    "description": "Sentrix Giveaway command.",
    "category": "Giveaway",
    "usage": ">gend [message_id]"
  },
  {
    "name": ">glist",
    "description": "Sentrix Giveaway command.",
    "category": "Giveaway",
    "usage": ">glist"
  },
  {
    "name": ">greroll",
    "description": "Sentrix Giveaway command.",
    "category": "Giveaway",
    "usage": ">greroll [message_id]"
  },
  {
    "name": ">gstart",
    "description": "Sentrix Giveaway command.",
    "category": "Giveaway",
    "usage": ">gstart [time] [winners] [prize]"
  },
  {
    "name": ">_bypass add",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_bypass add [user]"
  },
  {
    "name": ">_bypass remove",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_bypass remove [user]"
  },
  {
    "name": ">_bypass show",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_bypass show"
  },
  {
    "name": ">_channel add",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_channel add [channel]"
  },
  {
    "name": ">_channel remove",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_channel remove [channel]"
  },
  {
    "name": ">_channel show",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_channel show"
  },
  {
    "name": ">_command add",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_command add [command_name]"
  },
  {
    "name": ">_command remove",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_command remove [command_name]"
  },
  {
    "name": ">_command show",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_command show"
  },
  {
    "name": ">_user add",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_user add [user]"
  },
  {
    "name": ">_user remove",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_user remove [user]"
  },
  {
    "name": ">_user show",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">_user show"
  },
  {
    "name": ">ignore",
    "description": "Sentrix Ignore Channels command.",
    "category": "Ignore Channels",
    "usage": ">ignore"
  },
  {
    "name": ">addinvites",
    "description": "Sentrix Invite Tracker command.",
    "category": "Invite Tracker",
    "usage": ">addinvites [member] [amount]"
  },
  {
    "name": ">invitelogging",
    "description": "Sentrix Invite Tracker command.",
    "category": "Invite Tracker",
    "usage": ">invitelogging [channel]"
  },
  {
    "name": ">invites",
    "description": "Sentrix Invite Tracker command.",
    "category": "Invite Tracker",
    "usage": ">invites [member]"
  },
  {
    "name": ">invitesleaderboard",
    "description": "Sentrix Invite Tracker command.",
    "category": "Invite Tracker",
    "usage": ">invitesleaderboard"
  },
  {
    "name": ">resetinvites",
    "description": "Sentrix Invite Tracker command.",
    "category": "Invite Tracker",
    "usage": ">resetinvites [member]"
  },
  {
    "name": ">setinvites",
    "description": "Sentrix Invite Tracker command.",
    "category": "Invite Tracker",
    "usage": ">setinvites [member] [amount]"
  },
  {
    "name": ">j2creset",
    "description": "Sentrix J2C (Join To Create) command.",
    "category": "J2C (Join To Create)",
    "usage": ">j2creset"
  },
  {
    "name": ">j2csetup",
    "description": "Sentrix J2C (Join To Create) command.",
    "category": "J2C (Join To Create)",
    "usage": ">j2csetup"
  },
  {
    "name": ">joindm",
    "description": "Sentrix Joindm command.",
    "category": "Joindm",
    "usage": ">joindm"
  },
  {
    "name": ">joindm disable",
    "description": "Sentrix Joindm command.",
    "category": "Joindm",
    "usage": ">joindm disable"
  },
  {
    "name": ">joindm enable",
    "description": "Sentrix Joindm command.",
    "category": "Joindm",
    "usage": ">joindm enable"
  },
  {
    "name": ">joindm message",
    "description": "Sentrix Joindm command.",
    "category": "Joindm",
    "usage": ">joindm message [message]"
  },
  {
    "name": ">joindm test",
    "description": "Sentrix Joindm command.",
    "category": "Joindm",
    "usage": ">joindm test"
  },
  {
    "name": ">minecraft reset",
    "description": "Sentrix Minecraft command.",
    "category": "Minecraft",
    "usage": ">minecraft reset [interaction]"
  },
  {
    "name": ">minecraft setup",
    "description": "Sentrix Minecraft command.",
    "category": "Minecraft",
    "usage": ">minecraft setup [interaction]"
  },
  {
    "name": ">minecraft status",
    "description": "Sentrix Minecraft command.",
    "category": "Minecraft",
    "usage": ">minecraft status [interaction]"
  },
  {
    "name": ">audit",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">audit [limit]"
  },
  {
    "name": ">ban",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">ban [user] [reason]"
  },
  {
    "name": ">clear",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear [Choice] [int]] [Amount]"
  },
  {
    "name": ">clear all",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear all [search]"
  },
  {
    "name": ">clear bot",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear bot [prefix] [search]"
  },
  {
    "name": ">clear contains",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear contains [string]"
  },
  {
    "name": ">clear embeds",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear embeds [search]"
  },
  {
    "name": ">clear emoji",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear emoji [search]"
  },
  {
    "name": ">clear files",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear files [search]"
  },
  {
    "name": ">clear images",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear images [search]"
  },
  {
    "name": ">clear reactions",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear reactions [search]"
  },
  {
    "name": ">clear user",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clear user [member] [search]"
  },
  {
    "name": ">clearwarns",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clearwarns [user]"
  },
  {
    "name": ">clone",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">clone [channel]"
  },
  {
    "name": ">delemoji",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">delemoji [emoji]"
  },
  {
    "name": ">delsticker",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">delsticker [name]"
  },
  {
    "name": ">dmstaff",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">dmstaff [member] [message]"
  },
  {
    "name": ">enlarge",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">enlarge [emoji] [discord.PartialEmoji] [str]]"
  },
  {
    "name": ">give",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">give [member] [role]"
  },
  {
    "name": ">hideall",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">hideall"
  },
  {
    "name": ">jail",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">jail [member] [duration] [reason]"
  },
  {
    "name": ">jailhistory",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">jailhistory [member]"
  },
  {
    "name": ">kick",
    "description": "Kicks a member from the server with an optional reason.",
    "category": "Moderation",
    "usage": ">kick [member] [reason]"
  },
  {
    "name": ">lockall",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">lockall"
  },
  {
    "name": ">mute",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">mute [user] [time] [reason]"
  },
  {
    "name": ">nick",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">nick [member] [name]"
  },
  {
    "name": ">nuke",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">nuke"
  },
  {
    "name": ">prefix",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">prefix [prefix]"
  },
  {
    "name": ">purgebots",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">purgebots [prefix] [search]"
  },
  {
    "name": ">purgeuser",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">purgeuser [member] [search]"
  },
  {
    "name": ">removerole",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">removerole"
  },
  {
    "name": ">role",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">role [member] [role]"
  },
  {
    "name": ">role all",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">role all [role]"
  },
  {
    "name": ">role bots",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">role bots [role]"
  },
  {
    "name": ">role create",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">role create [name]"
  },
  {
    "name": ">role delete",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">role delete [role]"
  },
  {
    "name": ">role humans",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">role humans [role]"
  },
  {
    "name": ">role rename",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">role rename [role] [newname]"
  },
  {
    "name": ">role temp",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">role temp [role] [time] [user]"
  },
  {
    "name": ">role unverified",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">role unverified [role]"
  },
  {
    "name": ">roleicon",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">roleicon [role] [icon] [discord.PartialEmoji] [str]]"
  },
  {
    "name": ">rrole all",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">rrole all [role]"
  },
  {
    "name": ">rrole bots",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">rrole bots [role]"
  },
  {
    "name": ">rrole humans",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">rrole humans [role]"
  },
  {
    "name": ">rrole unverified",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">rrole unverified [role]"
  },
  {
    "name": ">slowmode",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">slowmode [seconds]"
  },
  {
    "name": ">snipe",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">snipe"
  },
  {
    "name": ">topcheck",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">topcheck"
  },
  {
    "name": ">topcheck disable",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">topcheck disable"
  },
  {
    "name": ">topcheck enable",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">topcheck enable"
  },
  {
    "name": ">unban",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">unban [user] [reason]"
  },
  {
    "name": ">unbanall",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">unbanall"
  },
  {
    "name": ">unhideall",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">unhideall"
  },
  {
    "name": ">unjail",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">unjail [member]"
  },
  {
    "name": ">unlock",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">unlock [channel]"
  },
  {
    "name": ">unlockall",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">unlockall"
  },
  {
    "name": ">unmute",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">unmute [user]"
  },
  {
    "name": ">unslowmode",
    "description": "Sentrix Moderation command.",
    "category": "Moderation",
    "usage": ">unslowmode"
  },
  {
    "name": ">_np add",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">_np add [user]"
  },
  {
    "name": ">_np list",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">_np list"
  },
  {
    "name": ">_np remove",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">_np remove [user]"
  },
  {
    "name": ">_np reset",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">_np reset"
  },
  {
    "name": ">_np status",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">_np status [user]"
  },
  {
    "name": ">autonp",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">autonp"
  },
  {
    "name": ">autonp_guild add",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">autonp_guild add [guild_id]"
  },
  {
    "name": ">autonp_guild list",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">autonp_guild list"
  },
  {
    "name": ">autonp_guild remove",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">autonp_guild remove [guild_id]"
  },
  {
    "name": ">autoplay",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">autoplay"
  },
  {
    "name": ">clearqueue",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">clearqueue"
  },
  {
    "name": ">disconnect",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">disconnect"
  },
  {
    "name": ">join",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">join"
  },
  {
    "name": ">loop",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">loop"
  },
  {
    "name": ">nowplaying",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">nowplaying"
  },
  {
    "name": ">pause",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">pause"
  },
  {
    "name": ">play",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">play [query]"
  },
  {
    "name": ">queue",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">queue"
  },
  {
    "name": ">replay",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">replay"
  },
  {
    "name": ">resume",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">resume"
  },
  {
    "name": ">search",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">search [query]"
  },
  {
    "name": ">seek",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">seek [percentage]"
  },
  {
    "name": ">shuffle",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">shuffle"
  },
  {
    "name": ">skip",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">skip"
  },
  {
    "name": ">stop",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">stop"
  },
  {
    "name": ">volume",
    "description": "Sentrix Music command.",
    "category": "Music",
    "usage": ">volume [level]"
  },
  {
    "name": ">createrr",
    "description": "Sentrix Reaction Roles command.",
    "category": "Reaction Roles",
    "usage": ">createrr [channel] [message_id] [emoji] [role]"
  },
  {
    "name": ">dmrr",
    "description": "Sentrix Reaction Roles command.",
    "category": "Reaction Roles",
    "usage": ">dmrr [mode]"
  },
  {
    "name": ">antinuke",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">antinuke [option]"
  },
  {
    "name": ">authorise add",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">authorise add [member]"
  },
  {
    "name": ">authorise list",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">authorise list"
  },
  {
    "name": ">authorise remove",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">authorise remove [member]"
  },
  {
    "name": ">blacklist",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">blacklist"
  },
  {
    "name": ">blacklistword",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">blacklistword"
  },
  {
    "name": ">blacklistword add",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">blacklistword add [word]"
  },
  {
    "name": ">blacklistword config",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">blacklistword config"
  },
  {
    "name": ">blacklistword remove",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">blacklistword remove [word]"
  },
  {
    "name": ">blacklistword reset",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">blacklistword reset"
  },
  {
    "name": ">bypass add",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">bypass add [target] [discord.Role]]"
  },
  {
    "name": ">bypass list",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">bypass list"
  },
  {
    "name": ">bypass remove",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">bypass remove [target] [discord.Role]]"
  },
  {
    "name": ">emergency",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">emergency"
  },
  {
    "name": ">emergency disable",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">emergency disable"
  },
  {
    "name": ">emergency enable",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">emergency enable"
  },
  {
    "name": ">emergencyrestore",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">emergencyrestore"
  },
  {
    "name": ">emergencysituation",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">emergencysituation"
  },
  {
    "name": ">guild add",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">guild add [guild_id]"
  },
  {
    "name": ">guild remove",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">guild remove [guild_id]"
  },
  {
    "name": ">guild show",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">guild show"
  },
  {
    "name": ">nitro",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">nitro"
  },
  {
    "name": ">role add",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">role add [role]"
  },
  {
    "name": ">role list",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">role list"
  },
  {
    "name": ">role remove",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">role remove [role]"
  },
  {
    "name": ">unwhitelist",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">unwhitelist [member]"
  },
  {
    "name": ">user add",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">user add [user]"
  },
  {
    "name": ">user remove",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">user remove [user]"
  },
  {
    "name": ">user show",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">user show"
  },
  {
    "name": ">whitelist",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">whitelist [member]"
  },
  {
    "name": ">whitelisted",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">whitelisted"
  },
  {
    "name": ">whitelistreset",
    "description": "Sentrix Security & Antinuke command.",
    "category": "Security & Antinuke",
    "usage": ">whitelistreset"
  },
  {
    "name": ">nightmode",
    "description": "Sentrix Server command.",
    "category": "Server",
    "usage": ">nightmode"
  },
  {
    "name": ">nightmode disable",
    "description": "Sentrix Server command.",
    "category": "Server",
    "usage": ">nightmode disable"
  },
  {
    "name": ">nightmode enable",
    "description": "Sentrix Server command.",
    "category": "Server",
    "usage": ">nightmode enable"
  },
  {
    "name": ">stickymessage",
    "description": "Sentrix Sticky command.",
    "category": "Sticky",
    "usage": ">stickymessage"
  },
  {
    "name": ">stickymessage edit",
    "description": "Sentrix Sticky command.",
    "category": "Sticky",
    "usage": ">stickymessage edit [channel]"
  },
  {
    "name": ">stickymessage list",
    "description": "Sentrix Sticky command.",
    "category": "Sticky",
    "usage": ">stickymessage list"
  },
  {
    "name": ">stickymessage remove",
    "description": "Sentrix Sticky command.",
    "category": "Sticky",
    "usage": ">stickymessage remove [channel]"
  },
  {
    "name": ">stickymessage setup",
    "description": "Sentrix Sticky command.",
    "category": "Sticky",
    "usage": ">stickymessage setup [channel]"
  },
  {
    "name": ">ticket",
    "description": "Sentrix Ticket command.",
    "category": "Ticket",
    "usage": ">ticket"
  },
  {
    "name": ">ticket claim",
    "description": "Sentrix Ticket command.",
    "category": "Ticket",
    "usage": ">ticket claim"
  },
  {
    "name": ">ticket close",
    "description": "Sentrix Ticket command.",
    "category": "Ticket",
    "usage": ">ticket close"
  },
  {
    "name": ">ticket lock",
    "description": "Sentrix Ticket command.",
    "category": "Ticket",
    "usage": ">ticket lock"
  },
  {
    "name": ">ticket setup",
    "description": "Sentrix Ticket command.",
    "category": "Ticket",
    "usage": ">ticket setup [style] [channel]"
  },
  {
    "name": ">ticket transcript",
    "description": "Sentrix Ticket command.",
    "category": "Ticket",
    "usage": ">ticket transcript"
  },
  {
    "name": ">ticket unlock",
    "description": "Sentrix Ticket command.",
    "category": "Ticket",
    "usage": ">ticket unlock"
  },
  {
    "name": ">__list_ activedeveloper",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ activedeveloper"
  },
  {
    "name": ">__list_ admins",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ admins"
  },
  {
    "name": ">__list_ bans",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ bans"
  },
  {
    "name": ">__list_ boosters",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ boosters"
  },
  {
    "name": ">__list_ bots",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ bots"
  },
  {
    "name": ">__list_ createdat",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ createdat"
  },
  {
    "name": ">__list_ early",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ early"
  },
  {
    "name": ">__list_ emojis",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ emojis"
  },
  {
    "name": ">__list_ inrole",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ inrole [role]"
  },
  {
    "name": ">__list_ invoice",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ invoice"
  },
  {
    "name": ">__list_ joinedat",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ joinedat"
  },
  {
    "name": ">__list_ moderators",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ moderators"
  },
  {
    "name": ">__list_ roles",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">__list_ roles"
  },
  {
    "name": ">avatar",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">avatar [member] [discord.User]]]"
  },
  {
    "name": ">banner",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">banner"
  },
  {
    "name": ">banner server",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">banner server"
  },
  {
    "name": ">banner user",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">banner user [member] [discord.User]]]"
  },
  {
    "name": ">boostcount",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">boostcount"
  },
  {
    "name": ">calculator",
    "description": "Starts a new calculator session.",
    "category": "Utility",
    "usage": ">calculator"
  },
  {
    "name": ">channelinfo",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">channelinfo [channel]"
  },
  {
    "name": ">embed",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">embed"
  },
  {
    "name": ">github",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">github [search_query]"
  },
  {
    "name": ">hack",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">hack [member]"
  },
  {
    "name": ">hash",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">hash [algorithm] [message]"
  },
  {
    "name": ">hinglish",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">hinglish [text]"
  },
  {
    "name": ">invite",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">invite"
  },
  {
    "name": ">joined-at",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">joined-at"
  },
  {
    "name": ">list",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">list"
  },
  {
    "name": ">map",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">map [location]"
  },
  {
    "name": ">membercount",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">membercount"
  },
  {
    "name": ">permissions",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">permissions [member]"
  },
  {
    "name": ">ping",
    "description": "Shows the bot's WebSocket, API, and Database latencies.",
    "category": "Utility",
    "usage": ">ping"
  },
  {
    "name": ">poll",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">poll [message]"
  },
  {
    "name": ">qr",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">qr"
  },
  {
    "name": ">report",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">report [bug]"
  },
  {
    "name": ">rickroll",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">rickroll [url]"
  },
  {
    "name": ">roleinfo",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">roleinfo [role]"
  },
  {
    "name": ">servericon",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">servericon"
  },
  {
    "name": ">serverinfo",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">serverinfo"
  },
  {
    "name": ">setnotif",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">setnotif"
  },
  {
    "name": ">setnotif list",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">setnotif list"
  },
  {
    "name": ">setnotif reset",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">setnotif reset"
  },
  {
    "name": ">setnotif twitch",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">setnotif twitch [role] [channel]"
  },
  {
    "name": ">setnotif youtube",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">setnotif youtube [role] [channel]"
  },
  {
    "name": ">stats",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">stats"
  },
  {
    "name": ">status",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">status [user]"
  },
  {
    "name": ">steal",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">steal [emote]"
  },
  {
    "name": ">timer",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">timer [times] [title]"
  },
  {
    "name": ">token",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">token [user]"
  },
  {
    "name": ">uptime",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">uptime"
  },
  {
    "name": ">urban",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">urban [phrase]"
  },
  {
    "name": ">userinfo",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">userinfo [member] [discord.User]]]"
  },
  {
    "name": ">users",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">users"
  },
  {
    "name": ">vcinfo",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">vcinfo [channel]"
  },
  {
    "name": ">wizz",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">wizz"
  },
  {
    "name": ">yt",
    "description": "Sentrix Utility command.",
    "category": "Utility",
    "usage": ">yt [search_query]"
  },
  {
    "name": ">vanityroles",
    "description": "Sentrix Vanityroles command.",
    "category": "Vanityroles",
    "usage": ">vanityroles"
  },
  {
    "name": ">vanityroles reset",
    "description": "Sentrix Vanityroles command.",
    "category": "Vanityroles",
    "usage": ">vanityroles reset"
  },
  {
    "name": ">vanityroles setup",
    "description": "Sentrix Vanityroles command.",
    "category": "Vanityroles",
    "usage": ">vanityroles setup [vanity] [role] [channel]"
  },
  {
    "name": ">vanityroles show",
    "description": "Sentrix Vanityroles command.",
    "category": "Vanityroles",
    "usage": ">vanityroles show"
  },
  {
    "name": ">vc kick",
    "description": "Sentrix Voice command.",
    "category": "Voice",
    "usage": ">vc kick [member]"
  },
  {
    "name": ">vc lock",
    "description": "Sentrix Voice command.",
    "category": "Voice",
    "usage": ">vc lock"
  },
  {
    "name": ">vc mute",
    "description": "Sentrix Voice command.",
    "category": "Voice",
    "usage": ">vc mute [member]"
  },
  {
    "name": ">vc private",
    "description": "Sentrix Voice command.",
    "category": "Voice",
    "usage": ">vc private"
  },
  {
    "name": ">vc unlock",
    "description": "Sentrix Voice command.",
    "category": "Voice",
    "usage": ">vc unlock"
  },
  {
    "name": ">vc unprivate",
    "description": "Sentrix Voice command.",
    "category": "Voice",
    "usage": ">vc unprivate"
  },
  {
    "name": ">voice",
    "description": "Sentrix Voice command.",
    "category": "Voice",
    "usage": ">voice"
  },
  {
    "name": ">fastgreet_add",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">fastgreet_add [channel]"
  },
  {
    "name": ">fastgreet_list",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">fastgreet_list"
  },
  {
    "name": ">fastgreet_remove",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">fastgreet_remove [channel]"
  },
  {
    "name": ">greet",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">greet"
  },
  {
    "name": ">greet autodelete",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">greet autodelete [time]"
  },
  {
    "name": ">greet channel",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">greet channel"
  },
  {
    "name": ">greet config",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">greet config"
  },
  {
    "name": ">greet edit",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">greet edit"
  },
  {
    "name": ">greet reset",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">greet reset"
  },
  {
    "name": ">greet setup",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">greet setup"
  },
  {
    "name": ">greet test",
    "description": "Sentrix Welcomer command.",
    "category": "Welcomer",
    "usage": ">greet test"
  }
],
  faqs: [
    { q: "Is Sentrix free?", a: "Yes. Sentrix is a free public bot. Invite it and use every feature at no cost." },
    { q: "What is the default prefix?", a: "The default prefix is `>`. Run `>help` to see all modules. Server admins can change the prefix with the prefix command." },
    { q: "How do I start protecting my server?", a: "Invite Sentrix, then run `>antinuke enable` to turn on antinuke protection. Use `>help` to explore the other modules." },
    { q: "How many commands does Sentrix have?", a: "Sentrix has 599+ commands across security, moderation, automod, music, tickets, giveaways, leveling, logging and more." },
    { q: "Where can I get help?", a: "A support server is coming soon. Until then, use `>help` in your server." },
  ],
};

export type SiteConfig = typeof siteConfig;
