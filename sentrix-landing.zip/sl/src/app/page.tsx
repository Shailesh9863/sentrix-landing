import { SentrixLanding } from "@/components/landing/sentrix-landing";

export default function HomePage() {
  return <SentrixLanding />;
}

