# Sentrix Landing Page

Landing page for the **Sentrix** Discord bot (free public bot, prefix `>`).
Built with Next.js, React, Tailwind CSS and Framer Motion.

## Run locally
```bash
npm install
npm run dev
```

## Edit content
Almost everything (name, links, features, FAQ, commands) lives in `src/lib/site-config.ts`.
Set links via `.env` (see `.env.example`).

## Deploy
Vercel or Cloudflare Pages (connect the repo, framework: Next.js).

## Credits
Based on the MIT-licensed Fluorine landing page by Mohsin.Exe / CodeX Development. See `LICENSE`.
